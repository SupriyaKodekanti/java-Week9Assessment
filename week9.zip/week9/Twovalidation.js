var uname=document.getElementById("uname");
var pass = document.getElementById("pass");
var cpass = document.getElementById("cpass");
var btn = document.getElementById("btn");
uname.addEventListener("input",checkInputs);
pass.addEventListener("input",checkInputs);

//function to enable the disabled butoon.
function checkInputs(){
if(uname!=="" && pass!==""){
   btn.removeAttribute("disabled");
}else{
    btn.setAttribute("disabled","true");
}
}
function Create(){
   // Basic validation
            if (uname.trim() === '' || pass.trim() === '' || cpass.trim() === '') {
                alert("Username and passwords cannot be empty.");
                return;
            }
			//password and confirm password is same or not
            if (pass !== cpass) {
                alert("Passwords do not match. Please try again.");
                return;
            }
			//length of the password
            if (pass.length < 8) {
                alert("Password must be at least 8 characters long.");
                return;
            }
			//email contains
		var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
		if (input.value.match(validRegex)) {
		alert("Valid email address!");
    return ;
  } else {
    alert("Invalid email address!");
    return false;
  }
  return  window.location.href="https://www.google.com/";
}
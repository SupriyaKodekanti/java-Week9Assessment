var name=document.getElementById("name");
var email = document.getElementById("email");
var rating = document.getElementById("rating");
var place = document.getElementById("place");
var time = document.getElementById("time");
var tarea = document.getElementById("area");
var btn = document.getElementById("btn");

name.addEventListener("input",checkInputs);
email.addEventListener("input",checkInputs);
rating.addEventListener("input",checkInputs);
place.addEventListener("input",checkInputs);
time.addEventListener("input",checkInputs);
tarea.addEventListener("input",checkInputs);


function checkInputs(){
if(name!=="" && email!==""){
   btn.removeAttribute("disabled");
}else{
    btn.setAttribute("disabled","true");
}
}
//function to validate the email.
function registration(){
	 var passvalue = pass.value;
	 const checknum = /[0-9]/.test(passvalue); 
	var checklowcase =  /[a-z]/.test(passvalue); 
	var valid= /@/.test(passvalue);
    if(checknum && checklowcase){
        if(checknum&&valid){
            if(checklowcase && valid){
                window.location.href="https://www.google.com/";
            }
            else{
                alert("Password should contain atleast one lowercase and @gmail.com  ");
            }
        }
         else{
              alert("Password should contain atleast one numeric value and lowercase letter");
         }
    }else{
        alert("Password should contain atleast one numeric value and lowercase letter.");
        return false;
    }

}